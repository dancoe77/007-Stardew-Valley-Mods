I hope you enjoy this mod! 

Please put BOTH folders inside your MODS folder! Here's how the file tree should look:

Stardew Valley -> Mods -> [CP] Underdark Sewer / UnderdarkSewer

Both folders, separately, need to be in the Mods folder to work. The CP folder has the images and such, the other has code necessary to change the color of the water & fog.

Inside the CP folder, there is a "Config" file that you can edit to change which room is shown! 

humanoidroom - Default, made to go with my Elven Krobus mod. The room is more befitting of a humanoid, with a bed and other furniture.
creatureroom - alternate room that is more fitting for a shadowbrute or other creatures!

Map messages are currently only available in English! If you would like to make translations, please let me know, and I will update the file and credit you with it!

Hope you enjoy this mod! Have fun playing SDV!